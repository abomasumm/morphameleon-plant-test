Migrate src/ from JavaScript (ES modules) to TypeScript, strict mode, plain DOM instead of jQuery, as described in MIGRATION.md, without changing behaviour.

First pin the current behaviour that no existing test covers (modules without tests: src/cart.js, src/catalog.js, src/view.js, src/app.js, src/main.js; see the existing test names in MIGRATION.md) with characterization tests.
Then migrate following the approach in MIGRATION.md, in dependency order: src/cart.js -> src/catalog.js -> src/format.js -> src/view.js -> src/app.js -> src/main.js.

Acceptance:
- Every existing test passes unchanged, and every new characterization test passes before and after.
- money(12.3) returns "$12.30", money(12.345) returns "$12.35", and money(0) returns "$0.00"
- plural(1, "plant") returns "1 plant", while plural(0, "plant") and plural(2, "plant") return "0 plants" and "2 plants"
- createCart().add returns true and adds a line with qty 1 for an in-stock plant, but returns false and leaves lines unchanged when stock is 0 or the requested line has reached plant.stock
- byLight(PLANTS, "all") returns a copy containing every plant, while byLight(PLANTS, "low") returns only plants whose light equals "low"
- plantCard returns a jQuery article.card with data-id set to plant.id and its Add button disabled when stock is below 1 or inCart is at least stock
- mount(root) renders the catalog and returns the same cart used by the rendered controls, so adding through the UI updates cart.count and triggers cart.onChange
- no JavaScript source files left in scope
- all tests and the typecheck pass
