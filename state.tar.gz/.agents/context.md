<!-- goal: Migrate src/ from JavaScript (ES modules) to TypeScript, strict mode, plain DOM instead of jQuery, as described in MIGRATION.md, without changing behaviour.

First pin the current behaviour that no existing test covers (modules without tests: src/cart.js, src/catalog.js, src/view.js, src/app.js, src/main.js; see the existing test names in MIGRATION.md) with characterization tests.
Then migrate following the approach in MIGRATION.md, in dependency order: src/cart.js -> src/catalog.js -> src/format.js -> src/view.js -> src/app.js -> src/main.js.

Acceptance:
- Every existing test passes unchanged, and every new characterization test passes before and after.
- money(12.3) returns "$12.30", money(12.345) returns "$12.35", and money(0) returns "$0.00"
- plural(1, "plant") returns "1 plant", while plural(0, "plant") and plural(2, "plant") return "0 plants" and "2 plants"
- createCart().add returns true and adds a line with qty 1 for an in-stock plant, but returns false and leaves lines unchanged when stock is 0 or the requested line has reached plant.stock
- byLight(PLANTS, "all") returns a copy containing every plant, while byLight(PLANTS, "low") returns only plants whose light equals "low"
- plantCard returns a jQuery article.card with data-id set to plant.id and its Add button disabled when stock is below 1 or inCart is at least stock
- mount(root) renders the catalog and returns the same cart used by the rendered controls, so adding through the UI updates cart.count and triggers cart.onChange
- no JavaScript source files left in scope
- all tests and the typecheck pass | 2026-11-03 06:41:21 -->
## Repository and migration surface

This is a small static Vite/Vitest plant shop. Runtime code is entirely in `src/`; `index.html` loads `/src/main.js`, `src/style.css` defines the visual contract, and Vitest runs in jsdom (`vitest.config.js`). `package.json` already provides TypeScript, `strict: true`, jQuery, and `@types/jquery`; the migration must not alter `package.json`, `package-lock.json`, `tsconfig.json`, or `vitest.config.js`.

### Modules and current behavior

- **`src/cart.ts` target: `src/cart.js` — `createCart()`**
  - Creates a closure-local mutable `lines` array and listener array.
  - Exposes `lines`, `onChange`, `add`, `remove`, `count`, `subtotal`, `shipping`, `total`, and `toFreeShipping`.
  - `add(plant)` finds the first line with the same `id`. If found, it rejects when `line.qty >= plant.stock`; otherwise increments `qty`. For a new line, it rejects when `plant.stock < 1`. A successful add pushes `{ id, name, price, qty: 1 }`, synchronously calls every listener, and returns `true`; rejected adds return `false` without mutation or notification.
  - `remove(id)` removes only the first matching line, notifies synchronously, and otherwise does nothing.
  - `shipping()` is receiver-sensitive through `this.subtotal()`: free at subtotal `0` or `>= 75`, otherwise `6.5`. `total()` similarly depends on `this.subtotal()` and `this.shipping()`.
  - `lines` is publicly mutable; its exact line shape and object identity must not change. `PLANTS` and exported cart state must not become deeply readonly.

- **`src/catalog.ts` target: `src/catalog.js` — `PLANTS`, `byLight(plants, light)`**
  - `PLANTS` is a mutable exported array of `{ id, name, art, price, light, stock }`.
  - `"all"` or any falsy light returns a shallow copy via `slice()`; another light returns a filtered new array. No input mutation occurs.
  - A likely explicit schema is `Plant` plus a light union (`"low" | "medium" | "bright"`), but tightening `byLight`’s accepted values is a compile-time public API decision.

- **`src/format.ts` target: `src/format.js` — `money(n)`, `plural(n, word)`**
  - `money` rounds with `Math.round(n * 100) / 100` and always emits two decimals.
  - `plural` appends `"s"` unless `n === 1` numerically.
  - Existing `test/format.test.js` is immutable and covers `money(16.5)`, `money(29.99 * 3)`, `money(0)`, and plural values `1`, `3`, `0`. It does **not** cover the required `money(12.3)`, `money(12.345)`, or `plural(2, "plant")`.

- **`src/view.ts` target: `src/view.js` — `plantCard(plant, inCart)`, `cartPanel(cart)`**
  - `plantCard` currently returns a jQuery object wrapping `<article class="card" data-id="...">`.
  - It creates `.art`, `h3`, `.meta`, `.row`, a price `<strong>`, and `<button class="add">`.
  - Button text is `"Sold out"` when stock is below 1, otherwise `"All in cart"` when `inCart >= stock`, otherwise `"Add"`. The disabled property is true for sold-out or full cards.
  - `cartPanel` returns `<aside class="cart">`, heading `Cart (n plant[s])`, an empty paragraph or a `<ul>` of line items, remove buttons with exact `aria-label="Remove <name>"`, subtotal/shipping/total, and a free-shipping progress bar with inline percentage width.
  - `src/style.css` depends on these classes and DOM structure. Text should be assigned with DOM text APIs rather than unsafe HTML interpolation.

- **`src/app.ts` target: `src/app.js` — `mount(root)`**
  - Creates and returns the live cart, clears the root, and renders `.shop`, heading, `.filters`, `.grid`, and a cart slot.
  - Filters are `all`, `low`, `medium`, and `bright`; the active filter uses `.active`.
  - Delegates filter, add, and remove clicks. Add finds the plant by the card’s `data-id`; remove uses the line’s `data-id`.
  - `cart.onChange(render)` performs a full synchronous rerender of filters, cards, and cart. Native DOM delegation should remain attached to stable containers so rerenders do not duplicate handlers.
  - `mount(null)` currently does not throw because jQuery treats null as an empty set, although the documented contract is a DOM element.

- **`src/main.ts` target: `src/main.js`**
  - A side-effect-only entry point importing `mount` and calling `mount(document.getElementById("app"))`.
  - Strict DOM typing requires handling the nullable element. Preserving current browser behavior would mean a missing `#app` is a no-op; an assertion or throw would be a behavior change.
  - `index.html:11` explicitly references `/src/main.js`. Removing that file requires changing this reference to `/src/main.ts`, but `index.html` is outside the stated `src/` scope. Without that change, `npm run build` is expected to fail after the final rename.

## Tests and characterization work

Existing `test/format.test.js` must remain byte-for-byte unchanged. New characterization tests should be separate files so they run against JavaScript before migration and TypeScript afterward. Suggested coverage:

- `test/cart.test.ts`: successful/rejected adds, exact line shape, stock boundary, no notification on rejection, synchronous notification after mutation, remove behavior, count/subtotal/shipping/total/free-shipping behavior, and receiver-sensitive totals.
- `test/catalog.test.ts`: `"all"` is a copy rather than the same array, `"low"` membership, and input immutability.
- `test/format-regression.test.ts`: the three uncovered required examples.
- `test/view.test.ts`: card tag/class/data ID, child text, button label and disabled states; full empty/non-empty cart panel structure and totals.
- `test/app.test.ts`: initial catalog rendering, filtering, add/remove clicks, returned cart identity, `cart.count`, and `onChange` invocation.
- `test/main.test.ts`: dynamic-import side effect renders into `#app`; it will need isolated modules/import timing because `main` exports nothing.

Avoid pinning incidental jQuery internals unless the lead confirms that jQuery return types remain contractual. Structural DOM assertions can use a small test-side adapter for a native element versus a jQuery wrapper, allowing the same test to survive either implementation.

## Constraints, risks, and open decisions

1. **The migration brief is internally inconsistent.** The headline and `README.md` require “plain DOM instead of jQuery” and “no jQuery,” while `MIGRATION.md` requires `plantCard` to remain a jQuery return value and directs `view.ts` to use jQuery typings. The lead must choose:
   - prioritize truly native DOM, changing `plantCard`/`cartPanel` to return `HTMLElement`;
   - preserve the public jQuery wrapper, requiring jQuery to remain and weakening “no jQuery”; or
   - build native DOM but wrap it in jQuery solely to preserve the return contract.
2. **Task granularity conflicts with the framework switch.** If `view` becomes native DOM, `app` must change in the same migration step because current `app` consumes jQuery objects. One-module-per-task plus per-stage builds requires either retaining jQuery temporarily, combining `view` and `app`, or permitting an intermediate incompatible state.
3. **`index.html` must likely be authorized for the `main.js` → `main.ts` reference**, or the final build cannot pass.
4. Extensionless imports are supported by the bundler and `moduleResolution: "bundler"`; no package or compiler changes should be necessary.
5. No authentication, backend, persistence, or external schema exists. The only schemas are the TypeScript representations of plants, cart lines, cart methods, and filter values.
6. Keep exported names, argument meanings, mutable state shape, synchronous notification timing, DOM structure/classes/text, and stock limits unchanged.

## Suggested task sequence

1. **Pin cart** — add `test/cart.test.ts`; run against current `src/cart.js`.
2. **Pin catalog** — add `test/catalog.test.ts`.
3. **Pin format gaps** — add `test/format-regression.test.ts`; leave `test/format.test.js` untouched.
4. **Pin view** — add `test/view.test.ts`.
5. **Pin app** — add `test/app.test.ts`.
6. **Pin main** — add `test/main.test.ts`.
7. **Migrate cart**: `src/cart.js` → `src/cart.ts`.
8. **Migrate catalog**: `src/catalog.js` → `src/catalog.ts`.
9. **Migrate format**: `src/format.js` → `src/format.ts`.
10. **Migrate view**: `src/view.js` → `src/view.ts`.
11. **Migrate app**: `src/app.js` → `src/app.ts`.
12. **Migrate entry point**: `src/main.js` → `src/main.ts`; update `index.html` if scope is expanded.
13. **Final validation**: `npm test`, `npm run typecheck`, `npm run build`, and verify no `.js` files remain under `src/`.
